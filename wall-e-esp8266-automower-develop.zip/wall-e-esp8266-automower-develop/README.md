# wall-e-esp8266-automower

Firmware für ein ESP8266-Modul zur Anbindung eines Mähroboters Gardena / Husqvaran G3 ins WLAN.

### Links
- https://www.loxwiki.eu/pages/viewpage.action?pageId=48137811
- https://www.mikrocontroller.net/topic/304526#6198142

### Referenzen
- Robomower_V0.8.pdf